package com.ruskin.project.client.mapwidget;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PopupPanel;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.ruskin.project.client.MainWidget;

public class LayerSwitcher extends PopupPanel {
	private final Label lbl = new Label("Perspective");
	private final VerticalPanel holder = new VerticalPanel();
	private final CheckBox Switzerland = new CheckBox(" Switzerland");
	private Boolean SwissOn = false;
	private final MainWidget master;
	
	public LayerSwitcher (MainWidget master) {
		this.master = master;
		
		buildUI();
	}

	private void buildUI() {
		holder.setSize("200px", "100px");
		
		lbl.getElement().addClassName("perspectiveLbl");
		Switzerland.getElement().addClassName("perspective");
		holder.getElement().addClassName("perspective");
		
		holder.add(lbl);
		holder.add(Switzerland);
		
		setWidget(holder);

		this.getElement().getStyle().setZIndex(1500);
		
		Switzerland.addClickHandler(new ClickHandler() {
			public void onClick(ClickEvent Event) {
				if(Switzerland.getValue()) {
					SwissOn = true;
				} else {
					SwissOn = false;
				}
				master.getMap().updateVisibleLayers();
			}
		});
	}

	public VerticalPanel getHolder() {
		return holder;
	}
	
	public Boolean getSwitzerland() {
		return SwissOn;
	}
}
