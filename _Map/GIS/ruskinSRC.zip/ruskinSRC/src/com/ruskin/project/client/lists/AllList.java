package com.ruskin.project.client.lists;

import java.util.ArrayList;

import com.ruskin.project.shared.GWTLocation;

@SuppressWarnings("serial")
public class AllList extends ArrayList<GWTLocation>{
	
	public AllList() {
		
	}
		//the original implementation for reference
		
		/*GWTLocation gwtC = GWTLocation.createGWTContact("London");
		gwtC.setCountry("Great Britain");
		gwtC.setLocation("London");
		gwtC.setLatitude(51.50853);
		gwtC.setLongitude(-0.12574);
		gwtC.setArrivalDate("N/A");
		gwtC.setDepartDate("14 May, 1833");
		gwtC.setDateRef(0);
		
		GWTLocation gwtC2 = GWTLocation.createGWTContact("Dover");
		gwtC2.setCountry("Great Britain");
		gwtC2.setLocation("Dover");
		gwtC2.setLongitude(1.3);
		gwtC2.setLatitude(51.13333);
		gwtC2.setArrivalDate("14 May, 1833");
		gwtC2.setDepartDate("15 May, 1833");
		gwtC2.setDateRef(514);
		*/
	
	public void addLocation(GWTLocation location) {
		this.add(location);
	}
	
	public GWTLocation getContact(String id) {
		final GWTLocation c = new GWTLocation();
		int location = -1;
		for (int i=0; i<this.size(); i++) {
			if(this.get(i).getId().matches(id)) {
				location = i;
			}
		}
		if(location >=0 ) {
			return this.get(location);
		}
		return c;
	}
	
	public int getRef(String date) {
		int ref = 0;
		for (GWTLocation c : this) {
			if (c.getArrivalDate().matches(date)) {
				ref = c.getDateRef();
			}
		}
		return ref;
	}

	public int getSize() {
		return this.size();
	}

}
